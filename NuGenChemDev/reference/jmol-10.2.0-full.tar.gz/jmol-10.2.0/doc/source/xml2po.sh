#!/bin/sh
#
# wrapper script for xml2po.py python script

echo $*
python $*

echo done.

